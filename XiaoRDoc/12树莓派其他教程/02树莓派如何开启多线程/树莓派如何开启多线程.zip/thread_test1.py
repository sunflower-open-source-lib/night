import thread
import time

global flag
flag = 0

def thread1():
	global flag
	while True:
		time.sleep(3)
		flag = 1

thread.start_new_thread(thread1, ())

while True:
	if flag==1:
		print("get success!\n")
		flag = 0
	else:
		print("get fail!\n")
	time.sleep(1)