import thread
import time

def thread1():
	while True:
		print("\nThis is thread1!")
		time.sleep(1)

def thread2():
	while True:
		print("\nThis is thread2!")
		time.sleep(2)

thread.start_new_thread(thread1, ())
thread.start_new_thread(thread2, ())

while True:
	print("\nThis is the main thread!")
	time.sleep(4)