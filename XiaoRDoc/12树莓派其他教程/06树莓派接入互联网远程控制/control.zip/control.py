
import socket
import time
import json
import RPi.GPIO as GPIO
from time import ctime
import binascii
import time
import threading


#must be modified===
DEVICEID='3145'
APIKEY='d6468525d'
#modify end=========
#led = LED(17)
host="www.bigiot.net"
port=8181



LED0 = 10
LED1 = 9
LED2 = 25

########Morot drive port defination#################
ENA = 13	#//L298 Enalbe A
ENB = 20	#//L298 Enable B
IN1 = 19	#//Motor port 1
IN2 = 16	#//Motor port 2
IN3 = 21	#//Motor port 3
IN4 = 26	#//Motor port 4

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(LED0,GPIO.OUT,initial=GPIO.HIGH)
GPIO.setup(LED1,GPIO.OUT,initial=GPIO.HIGH)
GPIO.setup(LED2,GPIO.OUT,initial=GPIO.HIGH)

#########motor initialized to LOW##########
GPIO.setup(ENA,GPIO.OUT,initial=GPIO.LOW)
GPIO.setup(IN1,GPIO.OUT,initial=GPIO.LOW)
GPIO.setup(IN2,GPIO.OUT,initial=GPIO.LOW)
GPIO.setup(ENB,GPIO.OUT,initial=GPIO.LOW)
GPIO.setup(IN3,GPIO.OUT,initial=GPIO.LOW)
GPIO.setup(IN4,GPIO.OUT,initial=GPIO.LOW)

##########Robot's direction control###########################
def Motor_Forward():
	print 'motor forward'
	GPIO.output(ENA,True)
	GPIO.output(ENB,True)
	GPIO.output(IN1,True)
	GPIO.output(IN2,False)
	GPIO.output(IN3,True)
	GPIO.output(IN4,False)
	GPIO.output(LED1,False)#Headlight's anode to 5V, cathode to IO port
	GPIO.output(LED2,False)#Headlight's anode to 5V, cathode to IO port
	
def Motor_Backward():
	print 'motor_backward'
	GPIO.output(ENA,True)
	GPIO.output(ENB,True)
	GPIO.output(IN1,False)
	GPIO.output(IN2,True)
	GPIO.output(IN3,False)
	GPIO.output(IN4,True)
	GPIO.output(LED1,True)#Headlight's anode to 5V, cathode to IO port
	GPIO.output(LED2,False)#Headlight's anode to 5V, cathode to IO port
	
def Motor_TurnLeft():
	print 'motor_turnleft'
	GPIO.output(ENA,True)
	GPIO.output(ENB,True)
	GPIO.output(IN1,True)
	GPIO.output(IN2,False)
	GPIO.output(IN3,False)
	GPIO.output(IN4,True)
	GPIO.output(LED1,False)#Headlight's anode to 5V, cathode to IO port
	GPIO.output(LED2,True)#Headlight's anode to 5V, cathode to IO port
def Motor_TurnRight():
	print 'motor_turnright'
	GPIO.output(ENA,True)
	GPIO.output(ENB,True)
	GPIO.output(IN1,False)
	GPIO.output(IN2,True)
	GPIO.output(IN3,True)
	GPIO.output(IN4,False)
	GPIO.output(LED1,False)#Headlight's anode to 5V, cathode to IO port
	GPIO.output(LED2,True)#Headlight's anode to 5V, cathode to IO port
def Motor_Stop():
	print 'motor_stop'
	GPIO.output(ENA,False)
	GPIO.output(ENB,False)
	GPIO.output(IN1,False)
	GPIO.output(IN2,False)
	GPIO.output(IN3,False)
	GPIO.output(IN4,False)
	GPIO.output(LED1,True)#Headlight's anode to 5V, cathode to IO port
	GPIO.output(LED2,True)#Headlight's anode to 5V, cathode to IO port





#connect bigiot
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.settimeout(0)
while True:
	try:
		s.connect((host,port))
		break
	except:
		print('waiting for connect bigiot.net...')
		time.sleep(2)

#check in bigiot
#checkinBytes=bytes('{\"M\":\"checkin\",\"ID\":\"'+DEVICEID+'\",\"K\":\"'+APIKEY+'\"}\n',encoding='utf8') #python3
checkinBytes='{\"M\":\"checkin\",\"ID\":\"'+DEVICEID+'\",\"K\":\"'+APIKEY+'\"}\n'
s.sendall(checkinBytes)

#keep online with bigiot function
data=b''
flag=1
t=time.time()
def keepOnline(t):
	if time.time()-t>40:
		s.sendall(b'{\"M\":\"status\"}\n')
		print('check status')
		return time.time()
	else:
		return t

#say something to other device function
def say(s,id,content):
	#sayBytes=bytes('{\"M\":\"say\",\"ID\":\"'+id+'\",\"C\":\"'+content+'\"}\n',encoding='utf8')	#python3
	sayBytes='{\"M\":\"say\",\"ID\":\"'+id+'\",\"C\":\"'+content+'\"}\n'
	s.sendall(sayBytes)

#deal with message coming in
def process(msg,s,checkinBytes):
	msg=json.loads(msg)
	if msg['M'] == 'connected':
		s.sendall(checkinBytes)
	if msg['M'] == 'login':
		say(s,msg['ID'],'Welcome! Your public ID is '+msg['ID'])
	if msg['M'] == 'say':
		say(s,msg['ID'],'You have send to me:{'+msg['C']+'}')
		if msg['C'] == "play":
			GPIO.output(LED0,False)
			GPIO.output(LED1,False)
			GPIO.output(LED2,False)
			say(s,msg['ID'],'LED turns on!')
		if msg['C'] == "stop":
			GPIO.output(LED0,True)
			GPIO.output(LED1,True)
			GPIO.output(LED2,True)
			say(s,msg['ID'],'LED turns off!')
		if msg['C'] == "up":
			Motor_Forward()
		if msg['C'] == "down":
			Motor_Backward()
		if msg['C'] == "left":
			Motor_TurnLeft()
		if msg['C'] == "right":
			Motor_TurnRight()
		if msg['C'] == "pause":
			Motor_Stop()
	#for key in msg:
	#	print(key,msg[key])
	#print('msg',type(msg))

#main while
while True:
	try:
		d=s.recv(1)
		flag=True
	except:
		flag=False
		time.sleep(1)
		t = keepOnline(t)
	if flag:
		if d!=b'\n':
			data+=d
		else:
			#msg=str(data,encoding='utf-8')		#python3
			msg=data
			process(msg,s,checkinBytes)
			print(msg)
			data=b''
