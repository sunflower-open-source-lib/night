#!/usr/bin/python
# -*- coding:utf-8 -*-
import smbus
import time

address = 0x09

bus = smbus.SMBus(1)
while True:
	for i in range(10):
		bus.write_byte(address,i)
		time.sleep(0.5)
	for i in range(10):
		bus.write_byte(address,10-i)
		time.sleep(0.5)
