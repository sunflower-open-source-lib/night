# -*- coding: utf-8 -*-
import numpy as np
import cv2
img = cv2.imread('xiaor.jpg',0)	#0：gray 灰度；1或者不写，是全彩的
#img = cv2.imread('xiaor.jpg')#全部信息

cv2.imshow('image',img)	#把读取到img内的图像数据显示到名为image的窗口中
k = cv2.waitKey(0)&0xFF	#等待按键
if k == 27:   #	wait for ESC
	cv2.destroyAllWindows()	
elif k == ord('s'):	#wait for KEY 's' to save and exit  
	cv2.imwrite('grayimage.jpg',img)
	cv2.destroyAllWindows()