#coding:utf-8
#Python中声明文件编码的注释，编码格式指定为utf-8
import time					#导入time库，可使用时间函数。
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)	##信号引脚模式定义，使用.BCM模式
Sign_Red = 11				##定义红色的管脚IO
Sign_Yellow = 8				##定义黄色的管脚IO
GPIO.setwarnings(False)
GPIO.setup(Sign_Red,GPIO.OUT,initial=GPIO.LOW)##红色初始化为低电平
GPIO.setup(Sign_Yellow,GPIO.OUT,initial=GPIO.LOW)##黄色初始化为低电平

def	do_action():		##定义功能函数，在其他地方调用此函数。未调用不执行。
	GPIO.output(Sign_Red,True)##把电平拉高，红色灯亮
	GPIO.output(Sign_Yellow,False)##把电平拉低，黄色灯熄灭
	time.sleep(1)##延迟1秒
	GPIO.output(Sign_Red,False)##把电平拉低，红色灯熄灭
	GPIO.output(Sign_Yellow,True)##把电平拉高，黄色灯亮
	time.sleep(1)
	
for i in range(1,5):		#调用rang（）循环函数，功能类似 for（i =1;i<5;i++ ）执行4遍
	do_action()
'''
整个程序功能为：
	双色LED灯先亮红灯，然后亮黄灯，如此交替，循环执行4遍停止
	持续循环4遍
'''